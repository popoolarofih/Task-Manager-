-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2022 at 10:46 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `management`
--

-- --------------------------------------------------------

--
-- Table structure for table `assign`
--

CREATE TABLE `assign` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Information` varchar(330) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  `Officer` varchar(40) NOT NULL,
  `Manager` varchar(40) NOT NULL,
  `Date` varchar(200) NOT NULL,
  `File` varchar(200) NOT NULL,
  `AAssigndate` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assign`
--

INSERT INTO `assign` (`Id`, `Name`, `Title`, `Information`, `Email`, `Contact`, `Officer`, `Manager`, `Date`, `File`, `AAssigndate`) VALUES
(1, 'Taiwo Dada', 'Data Collection', 'You are to collect data from different people in the country.', 'taiwodada@gmail.com', '09064453525', 'Mr Rasak', 'Mr Ayodele', '2022-07-08', 'index.php', '2022-07-25 21:44:11.846173'),
(2, 'Mr Adekunle Oyeleye', 'Fetching API', 'You are to get apis from different sites', 'adekunlyyy@gmail.com', '08065748392', 'Mr Titilope', 'Mrs Oyeniyi', '2022-07-08', 'Project Management System Login Form.png', '2022-07-25 21:58:00.166962');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Id` int(200) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Title` varchar(200) NOT NULL,
  `Remark` varchar(300) NOT NULL,
  `Admin` varchar(200) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Manager` varchar(200) NOT NULL,
  `Date` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Id`, `Name`, `Title`, `Remark`, `Admin`, `Description`, `Manager`, `Date`) VALUES
(2, 'Mrs Oyeniyi', 'Fetching API', 'We tried our best', 'Mrs Oyenu', 'We coould not find the required Api', 'Mrs Oyeniyi', '2022-07-26 11:42:11.316610');

-- --------------------------------------------------------

--
-- Table structure for table `submit`
--

CREATE TABLE `submit` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Employee` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `Manager` varchar(100) NOT NULL,
  `File` varchar(100) NOT NULL,
  `Submitdate` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `submit`
--

INSERT INTO `submit` (`Id`, `Name`, `Employee`, `Email`, `Contact`, `Manager`, `File`, `Submitdate`) VALUES
(1, 'Fetching ', 'Mr Taiwo Dada', 'priyanka@gmail.com', '09064453525', 'Mrs Oyeniyi', '.babelrc.js', '2022-07-26 09:36:28.034045');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(2, 'rofih9', '$2y$10$9RM0E07URphpxRKVtLFYz.dy6JMPU///BepugLG8KTp82oO99gYvW', '2022-07-28 20:10:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assign`
--
ALTER TABLE `assign`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `submit`
--
ALTER TABLE `submit`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assign`
--
ALTER TABLE `assign`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `Id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `submit`
--
ALTER TABLE `submit`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
